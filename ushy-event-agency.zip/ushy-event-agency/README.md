# Ushy Event Agency website

A static website (HTML, CSS, JavaScript). No build step.

## Push to GitHub
```
git init
git add .
git commit -m "Ushy Event Agency website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ushy-event-agency.git
git push -u origin main
```

## Deploy on Vercel
1. Go to vercel.com, choose **Add New > Project**, and import the GitHub repo.
2. Framework Preset: **Other**. Leave the build command and output directory empty.
3. Click **Deploy**. Every push to `main` redeploys automatically.

## Edit
- Text and sections: `index.html`
- Colours and rounded corners: the variables at the top of `style.css`
- WhatsApp number: top of `script.js`
