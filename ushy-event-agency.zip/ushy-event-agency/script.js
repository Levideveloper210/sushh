// Edit these two values to change the contact details used by the buttons and form.
const WHATSAPP_NUMBER = "2348164833922"; // 0816 483 3922 in international format
const WHATSAPP_HELLO = "Hello Ushy Event Agency, I would like to enquire about an event.";

const waLink = (text) => `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;

document.querySelectorAll("[data-wa]").forEach((a) => {
  a.href = waLink(WHATSAPP_HELLO);
  a.target = "_blank";
  a.rel = "noopener";
});

const toggle = document.querySelector(".menu-toggle");
const nav = document.getElementById("nav");
toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", open);
});
nav.addEventListener("click", (e) => {
  if (e.target.tagName === "A") {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  }
});

document.getElementById("quote-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const name = (f.get("name") || "").trim();
  const phone = (f.get("phone") || "").trim();
  const type = f.get("type");
  const error = document.getElementById("form-error");
  if (!name || !phone || !type) { error.hidden = false; return; }
  error.hidden = true;
  const lines = [
    "Hello Ushy Event Agency, I would like a quote.",
    `Name: ${name}`,
    `Phone: ${phone}`,
    `Event: ${type}`,
    f.get("date") ? `Date: ${f.get("date")}` : "",
    f.get("message") ? `Details: ${f.get("message").trim()}` : "",
  ].filter(Boolean);
  window.open(waLink(lines.join("\n")), "_blank", "noopener");
});

document.getElementById("year").textContent = new Date().getFullYear();
